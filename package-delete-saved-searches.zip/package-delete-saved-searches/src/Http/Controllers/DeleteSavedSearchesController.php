<?php
namespace ProcessMaker\Package\PackageDeleteSavedSearches\Http\Controllers;

use ProcessMaker\Http\Controllers\Controller;
use ProcessMaker\Http\Resources\ApiCollection;
use ProcessMaker\Package\PackageDeleteSavedSearches\Models\Sample;
use RBAC;
use Illuminate\Http\Request;
use URL;


class PackageDeleteSavedSearchesController extends Controller
{
    public function deleteRequestSavedSearches() {
        $query = SavedSearch::where('user_id', '!=', 1)
                            ->where('type','request')
                            ->where(function($q){
                                $q->where('title','Started By Me')
                                ->orWhere('title','In Progress')
                                ->orWhere('title', 'Completed')
                                ->orWhere('title', 'All Requests');
                            })
                            ->delete();
        return json_encode(["message" => "Total number of Saved Searches deleted: " . $query]);
    }

    public function deleteTaskSavedSearches() {
        $query = SavedSearch::where('user_id', '!=', 1)
                            ->where('type','task')
                            ->where(function($q){
                                $q->where('title','Self Service')
                                ->orWhere('title','Completed')
                                ->orWhere('title', 'To Do');
                            })
                            ->delete();
        return json_encode(["message" => "Total number of Saved Search(es) deleted: " . $query]);
    }

    public function test(){
        $query = SavedSearch::where('user_id', '!=', 1)
                            ->where('type','request')
                            ->where(function($q){
                                $q->where('title','Self Service')
                                ->orWhere('title','Completed')
                                ->orWhere('title', 'To Do');
                            })
                            ->get();
        $query->toJson();
        return $query;
    }

}
