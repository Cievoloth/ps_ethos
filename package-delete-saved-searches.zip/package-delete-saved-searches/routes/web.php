<?php

Route::group(['middleware' => ['auth']], function () {
    Route::get('admin/package-delete-saved-searches', 'PackageDeleteSavedSearchesController@index')->name('package.skeleton.index');
    Route::get('package-delete-saved-searches', 'PackageDeleteSavedSearchesController@index')->name('package.skeleton.tab.index');
});
