<?php
use Illuminate\Support\Facades\Schema;
Artisan::command('package-delete-saved-searches:install', function () {
    Artisan::call('vendor:publish', [
        '--tag' => 'package-delete-saved-searches',
        '--force' => true
    ]);

    $this->info('Package Delete Saved Searches has been installed');
})->describe('Installs the required js files and table in DB');


