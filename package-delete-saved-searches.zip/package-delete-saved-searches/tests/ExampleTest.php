<?php
namespace Tests\PackageDeleteSavedSearches;

use Tests\TestCase;

class ExampleTest extends TestCase
{
    public function testExample()
    {
        $this->assertTrue(true);
    }
}
