<?php
Route::group(['middleware' => ['auth:api', 'bindings']], function() {
    Route::get('deleteRequestSavedSearches', 'DeleteSavedSearchesController@deleteRequestSavedSearches');
    Route::get('deleteTaskSavedSearches', 'DeleteSavedSearchesController@deleteTaskSavedSearches');
    Route::get('test', 'DeleteSavedSearchesController@test');
});
